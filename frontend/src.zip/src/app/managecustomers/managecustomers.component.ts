import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managecustomers',
  templateUrl: './managecustomers.component.html',
  styleUrls: ['./managecustomers.component.css']
})
export class ManagecustomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
