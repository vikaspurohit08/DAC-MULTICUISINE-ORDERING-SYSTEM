import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vieworders',
  templateUrl: './vieworders.component.html',
  styleUrls: ['./vieworders.component.css']
})
export class ViewordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
