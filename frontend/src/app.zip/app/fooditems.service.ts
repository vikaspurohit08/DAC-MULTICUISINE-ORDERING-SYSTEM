import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FooditemsService {

  constructor(private http:HttpClient) { }

  getFoodItemList(rest_id)
  {
    return this.http.get("http://localhost:8082/multicuisine/fooditems/list/" + rest_id);
  }

  getRestaurant(rest_id)
  {
    return this.http.get("http://localhost:8082/multicuisine/restaurant/list/id/" + rest_id);
  }


}
