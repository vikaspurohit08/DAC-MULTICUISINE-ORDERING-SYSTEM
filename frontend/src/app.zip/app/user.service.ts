import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  register(user)
  {
    return this.http.post("http://localhost:8080/multicuisine/user/signup",user);
  }

  login(user)
  {
    console.log(user);
    return this.http.post("http://localhost:8080/multicuisine/user/login",user);
  }

  forgot(user)
  {
    console.log(user);
    return this.http.post("http://localhost:8080/multicuisine/user/forgot",user);
  }

  otp(user,email)
  {
    console.log(user);
    return this.http.post("http://localhost:8080/multicuisine/user/otp?email="+email,user);
  }

  address(email,x)
  {
    return this.http.put("http://localhost:8080/multicuisine/user/address?email="+email,x);
  }

  change(data,email)
  {
    return this.http.post("http://localhost:8080/multicuisine/user/change?email="+email,data);
  }
}
